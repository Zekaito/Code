def largest_34(a):
    
    a.sort()#n(log(n))
    num = a[-3]+a[-4]
    return num
        
def largest_third(a):
    
    a.sort#n(log(n))
    x = len(a)//3#n
    num = 0
    
    for i in range(1,x+1):
        num = num + a[-i]
    return num

def third_at_least(a):
    
    a.sort()#n(log(n))
    x = (len(a)//3)+1#n
    run = 1
    
    for i in range(len(a)-1):#n
        
        if run == x:
            return a[i]
        elif a[i] == a[i+1]:
            run = run+1
        else:
            run = 1

    return None

def sum_tri(a,n):#n^3

    for x in range(len(a)):#n

        for y in range(len(a)):#n

            for z in range(len(a)):#n

                if a[x]+ a[y]+ a[z] == n:
                    return True

    return False

















                
