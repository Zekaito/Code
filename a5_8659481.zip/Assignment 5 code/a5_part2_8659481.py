class Point:
    'class that represents a point in the plane'

    def __init__(self, xcoord=0, ycoord=0):
        ''' (Point,number, number) -> None
        initialize point coordinates to (xcoord, ycoord)'''
        self.x = xcoord
        self.y = ycoord

    def setx(self, xcoord):
        ''' (Point,number)->None
        Sets x coordinate of point to xcoord'''
        self.x = xcoord

    def sety(self, ycoord):
        ''' (Point,number)->None
        Sets y coordinate of point to ycoord'''
        self.y = ycoord

    def get(self):
        '''(Point)->tuple
        Returns a tuple with x and y coordinates of the point'''
        return (self.x, self.y)

    def move(self, dx, dy):
        '''(Point,number,number)->None
        changes the x and y coordinates by dx and dy'''
        self.x += dx
        self.y += dy

    def __eq__(self, other):
        '''(Point,Point)->bool
        Returns True if self and other have the same coordinates'''
        return self.x == other.x and self.y == other.y
    def __repr__(self):
        '''(Point)->str
        Returns canonical string representation Point(x, y)'''
        return 'Point('+str(self.x)+','+str(self.y)+')'
    def __str__(self):
        '''(Point)->str
        Returns nice string representation Point(x, y).
        In this case we chose the same representation as in __repr__'''
        return 'Point('+str(self.x)+','+str(self.y)+')'


class Rectangle(Point):

    def __init__(self, x, y, color):
        '''(Rectangle,Point,Point,Str)--> None
        Initialize rectangle points to (x,y) and the color as the color'''
        
        self.bot_lef = x
        self.top_rig = y
        self.color = color

    def __eq__(self, other):
        '''(Rectangle,Rectangle)--> Bool
        Returns true if the points of the 2 given rectangles are the same and False if they are not'''
        if self.bot_lef == other.bot_lef:
            if self.top_rig == other.top_rig:
                if self.color == other.color:
                    return True
        return False

    def __str__(self):
        '''(Rectangle)--> Str
        Returns a scentence that describes a rectangles shape and where the bottom left corner and
        top right corner are'''
        return 'I am a ' +self.color+ ' rectangle with bottom left corner at (' +str(self.bot_lef.x)+','+str(self.bot_lef.y)+') and top right corner at ('+str(self.top_rig.x)+','+str(self.top_rig.y)+')'

    def get_bottom_left(self):
        '''(Rectangle)--> Point
        Returns the point of the bottom left corner of the rectangle'''
        return(self.bot_lef)

    def get_top_right(self):
        '''(Rectangle)--> Point
        Returns the point of the top right corner of the rectangle'''
        return(self.top_rig)

    def get_color(self):
        '''(Rectangle)--> Str
        Returns the color of the rectangle'''
        return(self.color)

    def reset_color(self,c):
        '''(Rectangle,Str)--> None
        Changes the color of rectangle'''
        self.color = c

    def __repr__(self):
        '''(Rectangle)--> Str
        Returns a representation of the rectangle by giving the 2 points and the color''' 
        return 'Rectangle('+str(self.bot_lef)+','+str(self.top_rig)+',"'+str(self.color)+'")'
        
    def get_perimeter(self):
        '''(Rectangle)-->int
        Calculates and returns the perimeter of the rectangle'''
        z1 = abs(self.top_rig.x - self.bot_lef.x)
        z2 = abs(self.top_rig.y - self.bot_lef.y)
        return 2*z1 + 2*z2

    def get_area(self):
        '''(Rectangle)--> int
        Calculates and returns the area of the rectangle'''
        z1 = abs(self.top_rig.x - self.bot_lef.x)
        z2 = abs(self.top_rig.y - self.bot_lef.y)
        return z1*z2

    def move(self,dx,dy):
        '''(Rectangle)--> None
        Move the points of the rectangles by the given dx and dy'''
        self.bot_lef.move(dx,dy)
        self.top_rig.move(dx,dy)

    def intersects(self,other):
        '''(Rectangle)--> Bool
        Returns True if the 2 given rectangles intersect and returns False if they don't'''
        if self.bot_lef.x <= other.top_rig.x and self.top_rig.y >= other.bot_lef.x:
            if self.bot_lef.y <= other.top_rig.y and self.top_rig.y >= other.bot_lef.y:
                return True

        return False
    

    def contains(self,z1,z2):
        '''(Rectangle,int,int)--> Bool
        Returns True if the points given by the (z1,z2) are in the rectangle and False if
        it is not in the rectangle'''
        if self.bot_lef.x <= z1 and self.top_rig.x >= z1:
            if self.bot_lef.y <= z1 and self.top_rig.y >= z2:
                return True

        return False
        

class Canvas(Rectangle):

    def __init__(self,x=[]):
        '''(Canvas,List)--> None
        Sets the canvas list to [] unless a lits is given'''
        self.lst=x

    def __len__(self):
        '''(Canvas)--> Int
        Returns the number of elements in the Canvas list'''
        return len(self.lst)

    def __repr__(self):
        '''(Canvas)--> Str
        Returns a string represenation of the elements of the canvas'''
        return 'Canvas('+str(self.lst)

    def add_one_rectangle(self,r):
        '''(Canvas,Rectangle)--> None
        Adds the given Rectangle to the Canvas list'''
        self.lst.append(r)

    def count_same_color(self,col):
        '''(Canvas,Str)--> Int
        Returns the number of rectangles that are given color''' 
        counter = 0
        for i in range(len(self.lst)):
            if self.lst[i].color == col:
                counter = counter + 1
        return counter

    def total_perimeter(self):
        '''(Canvas)--> int
        Returns the total perimeter of all the rectangles in the canvas'''
        total = 0
        for i in range(len(self.lst)):
            total = total + self.lst[i].get_perimeter()
        return total

    def min_enclosing_rectangle(self):
        '''(Canvas)--> Rectangle
        Returns the smallest rectangle that all the rectangles intersect'''
        if len(self.lst)==0:
            return None
        else:
            minx = self.lst[0].bot_lef.x
            maxx = self.lst[0].top_rig.x
            miny = self.lst[0].bot_lef.y
            maxy = self.lst[0].top_rig.y

            for i in range(len(self.lst)):
                if minx >= self.lst[i].bot_lef.x:
                    minx = self.lst[i].bot_lef.x
                    
                if maxx <= self.lst[i].top_rig.x:
                    maxx = self.lst[i].top_rig.x

                if miny >= self.lst[i].bot_lef.y:
                    miny = self.lst[i].bot_lef.y

                if maxy <= self.lst[i].top_rig.y:
                    maxy = self.lst[0].top_rig.y

            return print(Rectangle(Point(minx,miny),Point(maxx,maxy),'Blue'))

    def common_point(self):
        '''(Canvas)--> Bool
        Returns True if all teh rectangles intersect at a point and if not it returns False'''
        for i in range(len(self.lst)):
            for j in range(len(self.lst)):
                if self.lst[i].intersects(self.lst[j]) == False:
                    return False
        return True












