def digit_sum(n):
    n = str(n)
    if len(n) == 1:
        return int(n)
    else:
        return int(n[0]) + digit_sum(n[1:])

def digital_root(n):
    n = digit_sum(n)
    n = str(n)
    if len(n) == 1:
        return int(n)
    else:
        return digital_root(n)
