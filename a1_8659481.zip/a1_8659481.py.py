# Course: IT1 1120
# Assignment #1
# Tsang, Tyler
# 8659481


import math
import turtle
s=turtle.Screen()
t=turtle.Turtle()

######################################################################
#Question 1
######################################################################
def lbs2kg(w):
    '''
    (Number) -> Number

    Changes the given weight in pounds to kilograms

    lbs2kg(1)
    >>>0.453592Kg
    '''
    w=float(w)*0.453592
    print(w,'Kg')

######################################################################
#Question 2
###################################################################### 
def id_formater(fn,ln,app,city,year):
    '''
    (String,String,String,String,String) -> String

    Rearranges the given information into appleation, last name
    ,first name,city,year of birth 

    id_formater("Bob","John","Dr","Detroit","1932")
    >>>Dr.John,Bob(Detroit,1932)
    '''
    
    print(app,'.',ln,',',fn,'(',city,',',year,')')
    
######################################################################
#Question 3
######################################################################
def limerick_maker():
    '''
    Creates a limerick with the given name and city
    
    >>> limerick_maker()
    Give a name tyler
    Give a name of a cityottawa
    Everyone in  ottawa said go away
    To tyler  so tyler went out to play
    Except tyler  tripped on a pail
    Then tyler  started to wail
    So  tyler  didn't have a good day



    '''

    name=input('Give a name ')
    city=input('Give a name of a city')

    print('Everyone in ',city,'said go away')
    print('To',name,' so ',name,'went out to play')
    print('Except',name,' tripped on a pail')
    print('Then',name,' started to wail')
    print('So ',name," didn't have a good day")


    

######################################################################
#Question 4
######################################################################
def id_formater_display():
    '''
    Askes for user's information and rearranges the information
    into a different order

    >>> id_formater_display()
    What is your first name? Bob
    What is your last name? John
    What is your appellation? Dr
    Where were you born? Detroit
    What is your year of birth? 1932
    Dr . John , Bob ( Detroit , 1932 )
    
    '''

    xfn=input('What is your first name? ')
    xln=input('What is your last name? ')
    xapp=input('What is your appellation? ')
    xcity=input('Where were you born? ')
    xyear=input('What is your year of birth? ')

    id_formater(xfn,xln,xapp,xcity,xyear)

######################################################################
#Qeustion 5
######################################################################
def l2loz(w):
    '''
    (int)-->(float,float)
    Gives 2 integers that will equal the number given but on is divided by 16

    >>> l2loz(12.5)
    12 8.0
    '''

    l=math.floor(w)
    w=(w-l)*16
    print(l,w)

######################################################################
#Question 6
######################################################################
def draw_soccer_field():

    '''
    Draws a soccer field in turtle graphics

    '''
    
    #Outside
    t.penup()
    t.goto(-200,10)
    t.pendown()
    t.setheading(0)
    t.forward(400)
    t.left(90)
    t.forward(200)
    t.left(90)
    t.forward(400)
    t.left(90)
    t.forward(200)

    #Corner1
    t.penup()
    t.goto(-180,10)
    t.setheading(90)
    t.pendown()
    t.circle(20,90)

    #Corner2
    t.penup()
    t.goto(200,30)
    t.setheading(180)
    t.pendown()
    t.circle(20,90)

    #Corner3
    t.penup()
    t.goto(180,210)
    t.setheading(270)
    t.pendown()
    t.circle(20,90)

    #Corner4
    t.penup()
    t.goto(-200,190)
    t.setheading(0)
    t.pendown()
    t.circle(20,90)

    #Dot1
    t.penup()
    t.goto(-140,110)
    t.pendown()
    t.dot(5)

    #Dot2
    t.penup()
    t.goto(0,110)
    t.pendown()
    t.dot(5)

    #Dot3
    t.penup()
    t.goto(140,110)
    t.pendown()
    t.dot(5)

    #Middle line
    t.penup()
    t.goto(0,10)
    t.pendown()
    t.setheading(90)
    t.forward(200)

    #Center circle
    t.penup()
    t.goto(0,60)
    t.pendown()
    t.setheading(0)
    t.circle(50)

    #Left penalty
    t.penup()
    t.goto(-200,60)
    t.pendown()
    t.setheading(0)
    t.forward(80)
    t.left(90)
    t.forward(100)
    t.left(90)
    t.forward(80)

    #Left goal
    t.penup()
    t.goto(-200,70)
    t.pendown()
    t.setheading(0)
    t.forward(40)
    t.left(90)
    t.forward(80)
    t.left(90)
    t.forward(40)

    #Right penalty
    t.penup()
    t.goto(200,60)
    t.pendown()
    t.setheading(180)
    t.forward(80)
    t.right(90)
    t.forward(100)
    t.right(90)
    t.forward(80)

    #Right goal
    t.penup()
    t.goto(200,70)
    t.pendown()
    t.setheading(180)
    t.forward(40)
    t.right(90)
    t.forward(80)
    t.right(90)
    t.forward(40)

    #Right half
    t.penup()
    t.goto(120,140)
    t.pendown()
    t.setheading(225)
    t.circle(40,90)

    #Left half
    t.penup()
    t.goto(-120,80)
    t.pendown()
    t.setheading(45)
    t.circle(40,90)        

######################################################################
#Question 7
######################################################################
def median3(num1,num2,num3):
    '''
    Tells you which on the numbers given are the median of the 3 numbers

    (int,int,int)--> Response

    >>> median3(12,15,17)
    12  is the median. That is  False
    15  is the median. That is  True
    17  is the median. That is  False

    '''

    
    A=min(num2,num3)<=num1 and max(num2,num3)>=num1
    B=min(num1,num3)<=num2 and max(num1,num3)>=num2
    C=min(num1,num2)<=num3 and max(num1,num2)>=num3

    print(num1,' is the median. That is ',A)
    print(num2,' is the median. That is ',B)
    print(num3,' is the median. That is ',C)

######################################################################
#Question 8
######################################################################
def below_parabola(a,b,p,q):
    '''
    Responds if the point (p,q) is on or under the function y=ax^2+b

    (int,int,int,int) --> Boolean

    >>> below_parabola(2,2,1,0)
    True

    '''

    Answer= q <= (a*(p**2)+b)
    return Answer

######################################################################
#Question 9
######################################################################
def projected_grade(a1,A1,a2,A2,m,M):
    '''
    Gives the user the predicted final grade based on 2 assignments
    and the midterm grade

    (int,int,int,int,int,int)--> int

    >>> projected_grade(10,20,8,10,40,50)
    77.75

    '''
    p1=a1/A1
    p1=100*(round(p1,2))

    p2=a2/A2
    p2=100*(round(p2,2))
    
    p3=(p1+p2)/2

    Mid=m/M
    Mid=100*(round(Mid,2))

    Final=(0.05)*(p1+p2+p3)+(0.35)*Mid+(0.5)*Mid

    return Final

######################################################################
#Question 10
######################################################################

def projected_grade_V2():
    '''
    Gives the user the predicted final grade based on 2 assignments
    and the midterm grade but if the midterm and final weighted
    average is below 50%, the given percentage will be the lowest
    of either the overall grade or the midterm and final mark

    >>> projected_grade_V2()
    How many points did you get on Assignment 1?10
    What was the maximum possible number of points for Assignment 1?10
    How many points did you get on Assignment 2?4
    What was the maximum possible number of points for Assignment 2?10
    How many points did you get on the midterm?75
    What was the maximum possible number of points for the midterm?100
    Your predicted final grade is  74.25 %



    '''
    
    a1=int(input("How many points did you get on Assignment 1?"))
    A1=int(input("What was the maximum possible number of points for Assignment 1?"))
    a2=int(input("How many points did you get on Assignment 2?"))
    A2=int(input("What was the maximum possible number of points for Assignment 2?"))
    m=int(input("How many points did you get on the midterm?"))
    M=int(input("What was the maximum possible number of points for the midterm?"))

    p1=a1/A1
    p1=100*(round(p1,2))

    p2=a2/A2
    p2=100*(round(p2,2))
    
    p3=(p1+p2)/2

    Mid=m/M
    Mid=100*(round(Mid,2))

    Final1=(0.35)*Mid+(0.5)*Mid
    Final2=(0.05)*(p1+p2+p3)+(0.35)*Mid+(0.5)*Mid
    

    if Final1 < 50:
        Grade = min(Final1,Final2)

    else:
        Grade = Final2
    
    
    print("Your predicted final grade is ",Grade,'%')







######################################################################
#Question 11
######################################################################

def Change_to_coins(amount):
    '''
    Returns an amount of of change in the lowest number of coins

    (Float)-->int,int,int,int

    >>> Change_to_coins(1.42)
    5 1 1 2

    '''
    

    amount=amount*100
    
    q=int(amount//25)
    amount=amount%25
    
    d=int(amount//10)
    amount=amount%10

    n=int(amount//5)
    amount=amount%5

    amount=int(amount)
    
    print(q,d,n,amount)





