'''
ITI1120
Assignment:3 part 1a
Tsang, Tyler
865941
'''


def count_pos(l):
    '''
    (list)->Phrase
    Counts the number of positive integers there are in the list given
    '''

    
    counter = 0
    for i in l:
        if i > 0:
            counter= counter +1
    print('There are ',counter,' positive numbers in your list.')


x=input("Please input a list of numbers seperated by commas:")
y=list(eval(x))

count_pos(y)
