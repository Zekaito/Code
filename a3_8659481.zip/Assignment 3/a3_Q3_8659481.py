'''
ITI1120
Assignment:3 part 1a
Tsang, Tyler
865941
'''


def longest_run(l):
    '''
    (list)->Int
    This programs prints an integer of the longest running
    count of the same number in the list in a row
    '''


    run=1
    longest=1
    for i in range(len(l)-1):
        if l[i]==l[i+1]:
            run = run + 1
            if longest<run:
                longest=run
        else:
            run = 1
    print(longest)


x=input("Please input a list of numbers seperated by commas:")
if ',' in x:
    y=list(eval(x))
else:
    y=[]
    y.append(x)
longest_run(y)
