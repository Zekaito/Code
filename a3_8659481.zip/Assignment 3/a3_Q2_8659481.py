'''
ITI1120
Assignment:3 part 1b
Tsang, Tyler
865941
'''

def two_length_run(l):
    '''
    (list)->Boolean
    Returns true if there are 2 or more of the same number in a row
    otherwise, the program will return false
    '''
    
    if len(l) <2:
        return False

    for i in range(len(l)-1):
        if l[i]==l[i+1]:
            return True
    return False


x= input("Please input a list of numbers seperated by commas")
y= list(eval(x))

print(two_length_run(y))
